<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php echo "thank you getting in touch with us";?>
</body>
</html>