for local hosting use 
hostname=localhost
user=root
password=""


system admin LOGIN
username:franklinokech@gmail.com
password:missing123 //encrypted=78d4d2cb44775210245a434f81ad8b19

authorised user=makiadi
password=missing123

manager=frankmanager
passowrd=missing123

searcher=franksearcher
password=missing123

database name:missingpersons.sql

dictionary
report missing person-a logged in admin,authorised user manager or searcher can add details of a person who is deemed to be missing into the system.

report found-a logged admin,authorised user, manager or searcher can report a person who is currently reported to be missing to be found. the condition here is that the person must be in the system as missing.

reportlostandfound-a logged in admin,authorised user,manager or a searcher can report a person who is currently not reported in the system as missing but somehow the user has sighted a person who is deemed to be lost. the logged in user adds the lost and found into the system.

re-unite-a logged in admin,manager,authorised user or manager can reporter a person who is currently lost and found to be re-united i.e the person who reported him/her has finally found the missing person hence the status changes to completely found and the details are removed from the lost and found list.

..........................................................................................................................
..........................................................................................................................
.........................................................................................................................
......................DEVELOPED BY FRANKLIN - 2017..............................................................................
.........................................................................................................................
.........................................................................................................................
.........................................................................................................................
