<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php echo "continue to send the email";?>
</body>
</html>